#pragma once
#include "../world.h"

namespace TL
{
	class Enemy : public Component
	{

	};
}